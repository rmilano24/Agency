<div class="brix-fe-promo-wrapper">
	<span class="brix-fe-promo-bg"></span>
	<span class="brix-fe-promo-title"></span>

	<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?list=PLP2JkJpnBbLgAop9zznu6u3LNRYSVaU70" frameborder="0" allowfullscreen></iframe>

	<a href="http://goo.gl/1BHeIU" target="_blank" class="brix-fe-promo-action"></a>
</div>