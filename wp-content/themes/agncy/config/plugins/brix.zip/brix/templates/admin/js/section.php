<div data-type="{{ type }}" data-size="{{ size }}" class="brix-subsection brix-subsection-type-{{ type }} brix-subsection-{{ size.replace( '/', '-' ) }}">
	<div class="brix-subsection-rows-wrapper">
	</div>
</div>