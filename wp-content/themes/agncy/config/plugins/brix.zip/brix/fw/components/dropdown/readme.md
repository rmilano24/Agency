# Dropdown

## Markup structure

    <div class="brix-dropdown brix-component %brix-dropdown-top%">
        <a href="#" class="brix-trigger"></a>
        <div class="brix-dropdown-content"></div>
    </div>