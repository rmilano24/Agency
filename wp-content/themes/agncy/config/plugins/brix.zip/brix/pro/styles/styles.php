<?php if ( ! defined( 'BRIX_PRO' ) ) die( 'Forbidden' );

/* Progress bar. */
require_once( BRIX_PRO_FOLDER . 'styles/blocks/progress_bar/progress_bar.php' );

/* Team. */
require_once( BRIX_PRO_FOLDER . 'styles/blocks/team/team.php' );