<?php if ( ! defined( 'BRIX_PRO' ) ) die( 'Forbidden' );

/* Require the Entypo icon pack. */
require_once dirname( __FILE__ ) . '/icon_packs/entypo.php';

/* Require the Material design icon pack. */
require_once dirname( __FILE__ ) . '/icon_packs/material.php';

/* Require the Foundation icon pack. */
require_once dirname( __FILE__ ) . '/icon_packs/foundation.php';

/* Require the Linea icon pack. */
require_once dirname( __FILE__ ) . '/icon_packs/linea.php';