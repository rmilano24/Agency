<?php brix_team_block_get_picture( $data ); ?>
<?php brix_team_block_get_team_name( $data ); ?>
<?php brix_team_block_get_team_role( $data ); ?>
<?php brix_team_block_get_team_bio( $data ); ?>